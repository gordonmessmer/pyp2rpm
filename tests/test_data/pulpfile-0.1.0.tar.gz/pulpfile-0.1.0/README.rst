pulp_file
=========

.. image:: https://travis-ci.org/pulp/pulp_file.svg?branch=master
   :target: https://travis-ci.org/pulp/pulp_file

.. image:: https://coveralls.io/repos/pulp/pulp_file/badge.png?branch=master
   :target: https://coveralls.io/r/pulp/pulp_file?branch=master

A Pulp plugin to support hosting arbitrary files.

For more information, please see the `documentation <https://pulpfile.readthedocs.io/en/latest/>`_
or the `Pulp project page <https://pulpproject.org>`_.
